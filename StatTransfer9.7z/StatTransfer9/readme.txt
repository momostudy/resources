Stat/Transfer Version Nine Readme File

Version 9.04

New Support for Access 2007.  The new extension is .accdb.  You must have the 
newer Acccess drivers installed on your machine. These should be present if you
have installed Office 2007.   If you haven't, you can obtain the drivers from 
Microsoft (	http://tinyurl.com/2v2z2n ).

Support has been added for Excel 2007 files that are written by the Office
ODBC drivers, including those written by Access 2007.  

Finaly, this release has vastly improved Matlab support.  It can now read datasets
and matrices created by versions 7.1 through 2007, including those which are compressed.
It can now write matrices in version five format and datasets in version seven format.


Version 9.03.07.06.21

The default output format for writing Stata files was changed in 9.03 to Stata 10. 
This unfortunately created some confusion and difficulty, particularly for command
processor users.  This release adds a warning message and a new command line switch.

 /vy will cause Stata Version 9 to be output and is equivalent to
				set write-old-ver y
	
Additionally, you can set a version explicity, as in /v9.  Therefore if you want to write
a Version 9 Stata/SE file type:

	copy in.xxx stata/se out.dta /v9
	
The installer has been changed in this release to accept a new parameter, "noservice".  If you 
are running on XP (but not on Vista) and do not have sufficient privilages to install a 
service, run the installer with this parameter and you will get the old update mechanism.



Version 9.03

Support for Stata Version 10.
Stata Time (%tchxx) and DateTime (%tc and %tC) values are now supported.
Leapseconds in %tC variables are automatically removed when the file is read.


Version 9.02

Licensing mechanism was changed so that annual lease licensees can run
Stat/Transfer from a network server.


Verison 9.01 - Initial Release

